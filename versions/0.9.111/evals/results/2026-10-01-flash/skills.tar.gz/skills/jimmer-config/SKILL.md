---
name: jimmer-config
description: Verify official Jimmer 0.9.111 Spring and standalone Java/Kotlin configuration keys, defaults, processor alignment and trigger policy without later fork settings.
metadata:
  toolkit: jimmer-ai-toolkit
  kind: reference
---

# Configuration — Jimmer 0.9.111

Check resolved runtime **and** processor coordinates before changing a key. Official artifacts use `org.babyfish.jimmer`, aligned at `0.9.111`. Spring properties use `jimmer.*`; standalone client builders do not consume Spring YAML. No official Quarkus module/config namespace ships in this release.

Java Gradle dependencies (in a Java project):

```kotlin
dependencies {
    implementation("org.babyfish.jimmer:jimmer-sql:0.9.111")
    annotationProcessor("org.babyfish.jimmer:jimmer-apt:0.9.111")
}
```

Kotlin Gradle dependencies (with compatible Kotlin/KSP plugins):

```kotlin
dependencies {
    implementation("org.babyfish.jimmer:jimmer-sql-kotlin:0.9.111")
    ksp("org.babyfish.jimmer:jimmer-ksp:0.9.111")
}
```

In Spring use `jimmer-spring-boot-starter:0.9.111`, retain the matching processor, and add `jimmer-sql-kotlin` for Kotlin DSL use. Kotlin and KSP plugin versions must match each other; Jimmer's version is not the KSP plugin version. Runtime and annotation/KSP processors have separate dependency configurations; inspect both.

```yaml
jimmer:
  language: kotlin  # java for Java entities
  show-sql: true
  pretty-sql: true
  database-validation-mode: ERROR
  trigger-type: BINLOG_ONLY
```

Logging is for a suitable environment; avoid leaking values into production logs. Schema validation checks migrated schema and does not apply migrations. `BINLOG_ONLY` requires actual event delivery when event-based cache consistency is expected; transaction modes are not deprecated here.

Read [GUIDE.md](GUIDE.md) for source-verified keys. Verify by starting the actual framework context and inspecting effective client configuration, not merely YAML parsing.
