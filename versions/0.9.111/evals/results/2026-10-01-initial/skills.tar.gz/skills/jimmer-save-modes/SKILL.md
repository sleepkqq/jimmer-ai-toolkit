---
name: jimmer-save-modes
description: Choose Jimmer 0.9.111 graph-save modes, natural keys, association replacement, masks, optimistic locks and partial save results in Java and Kotlin.
metadata:
  toolkit: jimmer-ai-toolkit
  kind: reference
---

# Graph saves — Jimmer 0.9.111

Establish identity, allowed changes, transaction scope and required return shape separately. Target the official release, not newer save APIs.

| Root mode | Contract |
|---|---|
| `INSERT_ONLY` | Insert or constraint error; do not silently turn create into upsert |
| `INSERT_IF_ABSENT` | Insert if missing, do not update conflicting root |
| `UPDATE_ONLY` | Update existing root; verify missing-row behavior required by the caller |
| `UPSERT` | Insert/update by ID or key; can select first if native upsert is unavailable |
| `NON_IDEMPOTENT_UPSERT` | Also inserts objects with neither ID nor key; only for intentional non-idempotency |

Root mode does not select child behavior. For loaded collections:

| Associated mode | Effect |
|---|---|
| `REPLACE` | Insert/update supplied targets and dissociate missing members |
| `MERGE` | Insert/update supplied targets, retain missing members |
| `APPEND` | Insert supplied targets; existing-target conflicts are errors |
| `APPEND_IF_ABSENT` | Insert missing targets |
| `UPDATE` | Update existing targets |
| `VIOLENTLY_REPLACE` | Clear/reinsert; destructive semantics, extra work and trigger events |

Omitted collection = untouched; `[]` = loaded empty collection. `REPLACE` with `[]` removes links/members; `MERGE` does not clear them. Owned-child deletion also needs `@OnDissociate` on the owning reference. Removing many-to-many links does not delete shared targets. Set the mode explicitly when it matters: convenience overloads taking `SaveMode` can default associations to `MERGE`, unlike an unconfigured command's `REPLACE`.

## Same operation in both languages

Java, a generated Input or immutable entity:

```java
var result = sqlClient.saveCommand(input)
    .setMode(SaveMode.UPDATE_ONLY)
    .setAssociatedModeAll(AssociatedSaveMode.REPLACE)
    .execute();
Book saved = result.getModifiedEntity();
```

Kotlin:

```kotlin
val result = sqlClient.save(input) {
    setMode(SaveMode.UPDATE_ONLY)
    setAssociatedModeAll(AssociatedSaveMode.REPLACE)
}
val saved = result.modifiedEntity
```

`SimpleSaveResult` / `KSimpleSaveResult` expose modified/original entities and affected counts. **There is no `isAccepted` in 0.9.111.** Do not add the newer acceptance protocol or infer whole-graph success from one count. For a specific root use its affected-table count when the driver/operation's semantics permit; test conflicts on the actual dialect.

## Result shape

`modifiedEntity` is not automatically a full database row. Generated IDs and known save values may be present; unloaded properties still throw. Fetcher/View execution overloads already exist:

```java
BookView view = sqlClient.saveCommand(input)
    .setMode(SaveMode.INSERT_ONLY)
    .execute(BookView.class)
    .getModifiedView();
```

```kotlin
val view = sqlClient.saveCommand(input) {
    setMode(SaveMode.INSERT_ONLY)
}.execute(BookView::class).modifiedView
```

Use these for the required successful-save shape; they may run a follow-up fetch. Do not promise newer save-result `RETURNING` optimizations or `setSaveResultReadsAllProperties`. A conflicting `INSERT_IF_ABSENT` is not a general existing-row fetch: do not convert a partial conflict result blindly to a required-ID DTO. If the caller needs the unchanged existing row, use an explicit complete-key lookup and transaction/isolation policy, verified under concurrency. Never replace a strict no-update contract with `UPSERT` merely to retrieve an ID.

## Keys and options

- `@Key` / `setKeyProps([group,] props...)` choose natural identity; ID matching needs no natural key. `@KeyUniqueConstraint` must match real uniqueness. Null semantics (`isNullNotDistinct`) and MySQL's other unique constraints (`noMoreUniqueConstraints`) can affect native upsert.
- `setUpsertMask` limits insert/update columns; it does not authorize fields. Inputs should contain only caller-writable fields.
- `setIdOnlyAsReference[All]`, `setKeyOnlyAsReference[All]`, `setAutoIdOnlyTargetChecking[All]` control short references and checks. Reference existence is not tenant authorization.
- `setDissociateAction`, `setTargetTransferMode[All]`, `setDeleteMode` govern association changes. Child transfer must be intentional.
- `setPessimisticLock`, `setOptimisticLock`, `setTransactionRequired` preserve concurrency/transaction contracts. Do not remove a lock just to reduce selects.
- `setDumbBatchAcceptable`, `setMaxCommandJoinCount`, `setConstraintViolationTranslatable`, `addExceptionTranslator` are available; tune only for an observed need.

## Conditional writes

Use `@Version` or `setOptimisticLock` when mismatch must throw a conflict. For a business predicate that should report zero changed rows, use `createUpdate(...).where(...)` and inspect its count (`jimmer-dml`). Include identity and authorization in that predicate. **No `setUpdateWhere`, `VersionMode.ASSIGNMENT`, or save assignment-expression `set(...)` exists here.** Atomic arithmetic belongs in typed bulk update. Updating an externally assigned revision that way needs explicit comparison/assignment in SQL and intentional bypass of graph-save semantics.

## Verify

Test insert, duplicate key, missing update, stale version, omitted vs empty association and child transfer. Inspect `QueryReason`: `INTERCEPTOR`, `TRIGGER`, `OPTIMISTIC_LOCK`, `KEY_UNIQUE_CONSTRAINT_REQUIRED`, `UPSERT_NOT_SUPPORTED` explain extra preselection. `DraftPreProcessor` avoids original-state lookup only when it actually fits the business logic.

Sources: [save command](https://github.com/babyfish-ct/jimmer/blob/v0.9.111/project/jimmer-sql/src/main/java/org/babyfish/jimmer/sql/ast/mutation/SimpleEntitySaveCommand.java), [result](https://github.com/babyfish-ct/jimmer/blob/v0.9.111/project/jimmer-sql/src/main/java/org/babyfish/jimmer/sql/ast/mutation/SimpleSaveResult.java), [Kotlin operations](https://github.com/babyfish-ct/jimmer/blob/v0.9.111/project/jimmer-sql-kotlin/src/main/kotlin/org/babyfish/jimmer/sql/kt/ast/mutation/KSaveOperations.kt).
